para que el motor funcione solo instala rich con el comando

pip install rich