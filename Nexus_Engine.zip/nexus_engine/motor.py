import subprocess
import threading
import json
import os
import time
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.layout import Layout
from rich.live import Live

# Configuración de la consola Rich para efectos visuales
console = Console()

class NexusEngine:
    def __init__(self):
        """Inicializa los valores base del RPG"""
        self.afinidad = 0
        self.nombre_jugador = "Invitado"
        self.historia = self._cargar_datos()
        self.nodo_actual = "entrada_sistema"
        self.jugando = True

    def emitir_beeps(self, parametros):
        # Si 'frec' es una lista [440, 523, 659], tocamos una melodía
        frecuencias = parametros.get("frec", 440)
        tipo = parametros.get("tipo", "tri")
        dur = parametros.get("dur", 0.1)
        vol = parametros.get("vol", 0.5)

        def tocar():
            # Si es una sola nota, la convertimos en lista para el loop
            lista_frec = frecuencias if isinstance(frecuencias, list) else [frecuencias]
            for f in lista_frec:
                # Aquí sí usamos .run para que espere a que termine la nota antes de la siguiente
                subprocess.run(["play", "-q", "-v", str(vol), "-n", "synth", str(dur), tipo, str(f)])

        # Lanzamos el hilo para que la melodía suene mientras el texto aparece
        threading.Thread(target=tocar, daemon=True).start()



    def _cargar_datos(self):
        """Carga el archivo JSON y lo convierte en un diccionario para acceso rápido"""
        try:
            with open('juego.json', 'r', encoding='utf-8') as f:
                datos = json.load(f)
                # Convertimos lista a dict usando el 'id' como llave
                return {nodo['id']: nodo for nodo in datos}
        except FileNotFoundError:
            console.print("[bold red]ERROR: No se encontró juego.json[/]")
            exit()

    def limpiar_pantalla(self):
        os.system('clear')

    def leer_sprite(self, nombre_archivo):
        """Busca el arte ASCII en la carpeta /sprites"""
        ruta = os.path.join("sprites", nombre_archivo)
        if os.path.exists(ruta):
            with open(ruta, "r", encoding='utf-8') as f:
                return f.read()
        return f"[Archivo {nombre_archivo} no encontrado]"

    def escribir_texto(self, texto, velocidad=0.03):
        """Efecto de máquina de escribir para 'humanizar' el diálogo"""
        for char in texto:
            print(char, end='', flush=True)
            time.sleep(velocidad)
        print()

    def mostrar_interfaz(self):
        self.limpiar_pantalla()
        escena = self.historia[self.nodo_actual]
        #0. Sonido

        if "tono" in escena: 
          self.emitir_beeps(escena["tono"])

        # 1. Renderizado de Sprite
        sprite_art = self.leer_sprite(escena['sprite'])
        console.print(sprite_art)

        # 2. Barra de Estado (Afinidad)
        color_af = "green" if self.afinidad >= 0 else "red"
        status = Panel(f"👤 {self.nombre_jugador} | ❤️ Afinidad: [{color_af}]{self.afinidad}[/]", style="dim white")
        console.print(status)

        # 3. Cuadro de Diálogo
        # Usamos un Panel de Rich para que se vea profesional
        dialogo = Panel(
            Text(escena['texto'], style="italic white"),
            title=f"● {escena['personaje']} ●",
            border_style="bright_blue"
        )
        console.print(dialogo)

        # 4. Opciones de Ruta
        console.print("\n[bold yellow]ACCIONES:[/]")
        for i, opcion in enumerate(escena['opciones']):
            console.print(f" [bold cyan][{i+1}][/] {opcion['texto']}")

        self.gestionar_entrada(escena)

    def gestionar_entrada(self, escena):
        """Maneja la lógica de las decisiones del jugador"""
        try:
            opc_idx = int(input("\n> ")) - 1
            if 0 <= opc_idx < len(escena['opciones']):
                seleccion = escena['opciones'][opc_idx]
                
                # Actualizar Afinidad
                self.afinidad += seleccion.get('afinidad', 0)
                
                # Mover al siguiente nodo
                self.nodo_actual = seleccion['siguiente']
                
                # Verificar fin del juego
                if self.nodo_actual == "game_over" or self.nodo_actual == "fin":
                    self.limpiar_pantalla()
                    console.print(Panel("[bold red]CONEXIÓN PERDIDA... JUEGO TERMINADO[/]", expand=False))
                    self.jugando = False
            else:
                input("Selección inválida. Presiona Enter...")
        except ValueError:
            input("Por favor, ingresa el NÚMERO de la opción...")

# --- INICIO DEL PROGRAMA ---
if __name__ == "__main__":
    motor = NexusEngine()
    
    # Intro estética
    motor.limpiar_pantalla()
    console.print("[bold blue]Iniciando NEXUS OS...[/]", style="blink")
    time.sleep(1.5)

    while motor.jugando:
        motor.mostrar_interfaz()

